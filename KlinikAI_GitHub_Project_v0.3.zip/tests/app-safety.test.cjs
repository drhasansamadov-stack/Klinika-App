const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root,'app/src/main/assets/index.html'),'utf8');
const source = html.match(/<script>\s*([\s\S]*?)\s*<\/script>/)[1];
const engine = require('../app/src/main/assets/optimizer.js');
function context() {
  const storage = new Map();
  const elements = new Map();
  const el = name => {
    if (!elements.has(name)) elements.set(name,{value:'',innerHTML:'',textContent:'',classList:{add(){},remove(){},toggle(){}},querySelectorAll(){return []}});
    return elements.get(name);
  };
  const alerts=[];
  const globals={
    KlinikCost:engine,
    localStorage:{getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)},
    document:{getElementById:el,querySelectorAll(){return []},querySelector(){return {}}},
    window:{scrollTo(){}},alert: msg=>alerts.push(String(msg)),confirm:()=>true,
    structuredClone:global.structuredClone,
    console, Date, Math,
  };
  const vmContext=vm.createContext(globals);
  vm.runInContext(source.split('// Initialize')[0],vmContext);
  return { el, alerts, run: command => vm.runInContext(command,vmContext) };
}
test('HTML uses external deterministic optimizer rather than LLM costs',()=>{
  assert.match(html,/<script src="optimizer\.js"><\/script>/);
  assert.doesNotMatch(html,/fetch\(/);
  assert.match(html,/KlinikCost\.optimize/);
});
test('unknown symptoms never generate a random differential',()=>{
  const v=context();v.el('budget').value='250';v.el('symptoms').value='completely unknown symptom xyz';
  v.run('runAnalysis()');
  assert.equal(v.alerts.length,1);
  assert.match(v.alerts[0],/uydurulmur/);
  assert.equal(v.run('current'),null);
});
test('invalid or missing budget refuses analysis',()=>{
  const v=context();v.el('budget').value='';v.el('symptoms').value='dizuriya';
  v.run('runAnalysis()');assert.match(v.alerts[0],/büdcəni/);
});
test('no prices invented for symptoms with empty laboratory',()=>{
  const v=context();v.el('budget').value='250';v.el('symptoms').value='dizuriya uretral ifrazat';
  v.run('runAnalysis()');
  assert.ok(v.run('current')!==null);
  assert.ok(v.run('current.panel.every(x=>x.price===null)'));
  assert.ok(v.run('current.panel.some(x=>x.priority==="MANDATORY" && x.included)'));
});
test('CSV semicolon parsing handles quoted fields',()=>{
  const v=context();const a=v.run('parseCsv("Test Name;Price\\n\\\"X;Y\\\";12,50")');
  assert.equal(a[1][0],'X;Y');assert.equal(a[1][1],'12,50');
});
test('GitHub build project has no network permission and uses trusted assets origin',()=>{
  const manifest=fs.readFileSync(path.join(root,'app/src/main/AndroidManifest.xml'),'utf8');
  const kotlin=fs.readFileSync(path.join(root,'app/src/main/java/com/klinikai/clinical/MainActivity.kt'),'utf8');
  assert.doesNotMatch(manifest,/android.permission.INTERNET/);
  assert.match(kotlin,/WebViewAssetLoader/);
  assert.match(kotlin,/appassets.androidplatform.net/);
  assert.match(manifest,/android:allowBackup="false"/);
});
