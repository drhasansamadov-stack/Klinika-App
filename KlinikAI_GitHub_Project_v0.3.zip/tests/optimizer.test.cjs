const test = require('node:test');
const assert = require('node:assert/strict');
const { optimize, priceToCents } = require('../app/src/main/assets/optimizer.js');
const make = (key, priority, price) => ({ key, name:key, priority, price, reason:'Test', source:'demo' });
test('precise AZN price conversion rejects unknown, negative, and >2 fractional decimals', () => {
  assert.equal(priceToCents('12,50'), 1250);
  assert.equal(priceToCents('0.01'), 1);
  for (const x of [null, '', -1, '1.999', 'nan', '1e4']) assert.equal(priceToCents(x), null);
});
test('mandatory tests protected even when budget is insufficient', () => {
  const v=optimize([make('required','MANDATORY',285),make('optional','HIGH',5)],250);
  assert.equal(v.mandatoryCost,285);
  assert.equal(v.shortfall,35);
  assert.deepEqual(v.items.filter(i=>i.included).map(i=>i.key),['required']);
  assert.equal(v.budgetExceeded,true);
});
test('unknown-priced mandatory test stays included and blocks final cost',()=>{
  const v=optimize([make('unknown','MANDATORY',null),make('other','HIGH',5)],20);
  assert.equal(v.items.find(i=>i.key==='unknown').included,true);
  assert.deepEqual(v.unknownMandatory,['unknown']);
  assert.equal(v.selectedCostComplete,false);
  assert.equal(v.fullTotal,null);
});
test('maximizes clinical priority score rather than picking cheapest tests',()=>{
  const v=optimize([make('A','HIGH',70),make('B','MEDIUM',30),make('C','LOW',20),make('D','LOW',20)],70);
  assert.deepEqual(v.items.filter(i=>i.included).map(i=>i.key),['A']);
});
test('chooses value-optimal combination among same budget',()=>{
  const v=optimize([make('A','HIGH',40),make('B','HIGH',60),make('C','HIGH',60)],100);
  assert.equal(v.items.filter(i=>i.included).length,2);
  assert.equal(v.total,100);
});
test('all monetary totals use integer cents',()=>{
  const v=optimize([make('a','MANDATORY',0.1),make('b','HIGH',0.2)],0.3);
  assert.equal(v.total,0.3);
  assert.equal(v.shortfall,0);
});
test('test list is not mutated',()=>{
  const items=[make('a','LOW',2)];optimize(items,1);assert.equal(items[0].included,undefined);
});
test('duplicate keys rejected',()=>{
  assert.throws(()=>optimize([make('a','HIGH',1),make('a','HIGH',2)],10),/unikal/);
});
test('empty options valid',()=>{assert.equal(optimize([],0).total,0)});
