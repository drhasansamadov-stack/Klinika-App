/* Klinik AI offline deterministic cost/selection engine.
   IMPORTANT: Priority weights are doctor-reviewable proxies, NOT validated
   diagnostic yield estimates or substitutes for guideline evidence.
   No LLM or network code may calculate prices. */
(function (root) {
  'use strict';
  const SCORE = Object.freeze({ MANDATORY: 0, HIGH: 100, MEDIUM: 35, LOW: 10 });
  function priceToCents(price) {
    if (price === null || price === undefined || price === '') return null;
    const s = String(price).trim().replace(',', '.');
    if (!/^\d+(?:\.\d{1,2})?$/.test(s)) return null;
    const parts = s.split('.');
    const cents = Number(parts[0]) * 100 + Number((parts[1] || '').padEnd(2, '0'));
    return Number.isSafeInteger(cents) && cents >= 0 ? cents : null;
  }
  function budgetToCents(budget) {
    return priceToCents(budget);
  }
  function optimize(items, budget) {
    if (!Array.isArray(items) || budgetToCents(budget) === null) {
      throw new Error('Büdcə və analiz siyahısı etibarlı olmalıdır');
    }
    const maxBudget = budgetToCents(budget);
    const output = items.map(it => ({ ...it }));
    const seen = new Set();
    for (const it of output) {
      if (typeof it.key !== 'string' || !it.key || seen.has(it.key)) {
        throw new Error('Analiz açarları unikal və boş olmamalıdır');
      }
      if (!(it.priority in SCORE)) throw new Error('Naməlum klinik prioritet');
      seen.add(it.key);
    }
    const mandatory = output.filter(it => it.priority === 'MANDATORY');
    const unpricedMandatory = mandatory.filter(it => priceToCents(it.price) === null);
    const mandatoryCents = mandatory.reduce((n, it) => n + (priceToCents(it.price) ?? 0), 0);
    const selected = new Set(mandatory.map(it => it.key));
    const remaining = Math.max(0, maxBudget - mandatoryCents);
    const options = output.filter(it => it.priority !== 'MANDATORY' && priceToCents(it.price) !== null)
      .sort((a, b) => a.key.localeCompare(b.key));
    // Exact 0/1 knapsack with Pareto-frontier pruning. A state at higher cost
    // and no higher score can never beat a cheaper state in future iterations.
    let frontier = new Map([[0, { score: 0, keys: [] }]]);
    if (mandatoryCents <= maxBudget) {
      for (const it of options) {
        const cost = priceToCents(it.price);
        const next = new Map(frontier);
        for (const [spent, entry] of frontier.entries()) {
          const newCost = spent + cost;
          if (newCost > remaining) continue;
          const candidate = { score: entry.score + SCORE[it.priority], keys: [...entry.keys, it.key] };
          const old = next.get(newCost);
          if (!old || candidate.score > old.score) next.set(newCost, candidate);
        }
        // Increasing cost, keep states with strictly increasing scores.
        let highestScore = -1;
        const kept = new Map();
        for (const [costKey, state] of [...next].sort((a, b) => a[0] - b[0])) {
          if (state.score > highestScore) {
            kept.set(costKey, state);
            highestScore = state.score;
          }
        }
        frontier = kept;
      }
      let best = { cost: 0, score: -1, keys: [] };
      for (const [cost, entry] of frontier) {
        if (entry.score > best.score || (entry.score === best.score && cost < best.cost)) {
          best = { cost, score: entry.score, keys: entry.keys };
        }
      }
      best.keys.forEach(k => selected.add(k));
    }
    for (const it of output) {
      const cents = priceToCents(it.price);
      it.included = selected.has(it.key);
      if (it.priority === 'MANDATORY' && cents === null) {
        it.included = true; // never silently remove a mandatory recommendation
        it.excludedReason = 'Qiyməti məlum deyil; yekun məbləğ hesablana bilməz.';
      } else if (!it.included && cents === null) {
        it.excludedReason = 'Klinika bazasında təsdiqlənmiş qiymət yoxdur.';
      } else if (!it.included) {
        it.excludedReason = mandatoryCents > maxBudget
          ? 'Məcburi testlərin qiyməti büdcəni aşır; əlavə test seçilmədi.'
          : 'Büdcəyə uyğun, üstün prioritetli digər kombinasiya seçildi.';
      }
    }
    const selectedCents = output.filter(it => it.included)
      .reduce((n, it) => n + (priceToCents(it.price) ?? 0), 0);
    const allCents = output.reduce((n, it) => n + (priceToCents(it.price) ?? 0), 0);
    const allPriced = output.every(it => priceToCents(it.price) !== null);
    return {
      items: output,
      total: selectedCents / 100,
      fullTotal: allPriced ? allCents / 100 : null,
      mandatoryCost: mandatoryCents / 100,
      shortfall: Math.max(0, mandatoryCents - maxBudget) / 100,
      unknownMandatory: unpricedMandatory.map(it => it.name),
      selectedCostComplete: output.filter(it => it.included).every(it => priceToCents(it.price) !== null),
      budgetExceeded: selectedCents > maxBudget,
      budget: maxBudget / 100,
    };
  }
  root.KlinikCost = { optimize, priceToCents, budgetToCents };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.KlinikCost;
})(typeof globalThis !== 'undefined' ? globalThis : this);
