# Klinik AI — Android / GitHub Actions build

**Status:** offline clinical decision-support **prototype**, version `0.3.0`. It is **not** a verified medical device, autonomous diagnostic tool, or treatment planner. A doctor must validate all clinical decisions and the demo clinical rules before real-world use. Do **not** enter patient names, phone numbers, dates of birth, national IDs, or other directly identifying patient data. The demo rule labels, including `MANDATORY`, are **not** a substitute for current guidelines.

## Why this project exists

An earlier manually assembled APK had Android installation/signature compatibility problems. This repository uses the **official Android Gradle Plugin** to build and debug-sign a normal Android APK, rather than manually writing `AndroidManifest.xml` or DEX bytes. The application has its own new package ID `com.klinikai.clinical` to avoid signature collisions with the old experimental builds.

## Build on GitHub (recommended)

1. Create a new **private** repository named `klinik-ai` under your GitHub account. Do not put this project in an unrelated camera-tracking repository.
2. Upload **all** contents of this directory into the repository root, including the hidden `.github/workflows/` folder.
3. Open **Actions → Build Klinik AI APK → Run workflow** (or push a commit to `main`).
4. Open the completed green workflow, click **Artifacts → KlinikAI-Android-APK** and download the artifact ZIP.
5. Unzip it. Install the contained **`KlinikAI-debug.apk`** on the Android device. Allow APK installation from your browser/files app if requested.
6. If the APK installs but fails to launch, run **Actions → Optional Android emulator smoke test → Run workflow**, and share the failing log.

The build runs `node --test`, `gradle :app:assembleDebug`, `apksigner verify` and `aapt dump badging`. GitHub will supply Android SDK and Java through the workflow. No secrets or external AI subscription are needed for the offline build.

**APK output after CI:** `app/build/outputs/apk/debug/app-debug.apk`, exported as `KlinikAI-debug.apk`. This is a normal **debug-signed** APK for testing/sideloading, not a production Play Store release.

## Local Android Studio

Use JDK 17, Android SDK Platform 35, Build Tools 35.0.0, Gradle 8.9 and Android Gradle Plugin 8.7.3. Open this project root in Android Studio, configure an installed Gradle 8.9 distribution if prompted (a Gradle wrapper binary is not bundled), sync, and run **Build → Build APK(s)**.

The Android app is Kotlin and uses WebViewAssetLoader for a bundled offline HTML/JS UI. It is **not** yet Jetpack Compose or Room. Local test prices/cases use WebView localStorage and are **not encrypted**; keep only anonymous/demo data until a production security review and Room migration are complete.

## Offline functionality

- Azerbaijani responsive interface, dark mode
- Anonymous case form, symptom-driven differential demo, initial diagnosis is not absolute truth
- Local lab price catalog: CRUD, category filtering, active/inactive, CSV import
- No estimated prices: catalog prices only
- Deterministic 0/1 knapsack budget optimizer using integer qəpik and priority weight proxies
- Mandatory tests are never automatically discarded solely to meet the budget
- A missing-price mandatory test remains visible and blocks final approval until priced/reviewed
- Doctor may edit priorities/panel; approval action logs changes and writes case history
- JSON backup shown in a copyable text field (browser download intentionally not assumed to work in WebView)

### Important limitations

- No XLSX import in this build; save Excel sheets as `;`-delimited CSV
- Clinical heuristics are prototypes; do **not** infer that "mandatory" always applies in every clinical setting
- No live literature updates/medical source verification, no deployed Google AI Studio/Gemini backend
- No on-device patient-data encryption/authentication and no fully validated clinical terminology matching
- No live device installation test was performed in the local authoring environment (no SDK/emulator/network); GitHub's separate optional emulator workflow provides a path to test install/launch
- Not suitable for production patient care without formal clinical/security/regulatory review

## Testing without Android SDK

```bash
node --test tests/*.test.cjs
node --check app/src/main/assets/optimizer.js
```

The repository has no Node dependencies for these tests.

## Safety and future AI

**Do not put API keys into the APK or commit them to GitHub.** Any eventual Google AI Studio integration must run behind a private HTTPS server with authenticated requests, anonymization/minimization, explicit clinician approval before sending clinical data, evidence/provenance checks, and a fallback when AI is unavailable. A software-generation prompt for Google AI Studio is in `GOOGLE_AI_STUDIO_PROMPT.md`. Never paste real patient details into a prompt.

For future milestones: native Jetpack Compose + Room/SQLCipher or Android Keystore, safer XLSX import, evidence review/approval workflow, source/version metadata, doctor preferences independent from guidelines, audit integrity, authentication, and clinical validation.
