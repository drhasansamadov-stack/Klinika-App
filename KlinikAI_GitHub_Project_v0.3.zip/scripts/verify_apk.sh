#!/usr/bin/env bash
set -euo pipefail
APK="${1:-app/build/outputs/apk/debug/app-debug.apk}"
test -s "$APK" || { echo "APK not found: $APK" >&2; exit 1; }
unzip -t "$APK" | tail -1
unzip -l "$APK" | grep -E 'AndroidManifest.xml|classes.dex'
"${ANDROID_HOME:?Set ANDROID_HOME}/build-tools/35.0.0/apksigner" verify --verbose "$APK"
echo "Verified: $APK"
