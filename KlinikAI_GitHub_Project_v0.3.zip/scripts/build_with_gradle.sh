#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_HOME:?Install Android SDK and set ANDROID_HOME}"
command -v gradle >/dev/null || { echo "Install Gradle 8.9 (or use GitHub Actions)" >&2; exit 1; }
node --test tests/*.test.cjs
gradle --no-daemon :app:assembleDebug
bash scripts/verify_apk.sh
mkdir -p artifacts
cp app/build/outputs/apk/debug/app-debug.apk artifacts/KlinikAI-debug.apk
echo 'APK: artifacts/KlinikAI-debug.apk'
